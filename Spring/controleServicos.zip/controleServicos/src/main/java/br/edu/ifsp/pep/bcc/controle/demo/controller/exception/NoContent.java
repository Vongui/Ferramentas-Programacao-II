package br.edu.ifsp.pep.bcc.controle.demo.controller.exception;

public class NoContent extends RuntimeException {
    public NoContent(String message) {
        super(message);
    }
}
