package br.edu.ifsp.pep.bcc.controle.demo.controller.dto;

public record ClienteResponseDTO(int codigo ,String nome, String email, String telefone) {
}
