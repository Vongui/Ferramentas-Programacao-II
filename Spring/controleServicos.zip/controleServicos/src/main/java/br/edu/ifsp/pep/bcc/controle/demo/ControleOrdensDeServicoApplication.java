package br.edu.ifsp.pep.bcc.controle.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleOrdensDeServicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControleOrdensDeServicoApplication.class, args);
	}

}
