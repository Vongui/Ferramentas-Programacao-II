package br.edu.ifsp.pep.bcc.controle.demo.controller.dto;

import java.time.LocalDate;

public record OrdemServicoDTO(int clienteId, String formaPagamento) {
}
