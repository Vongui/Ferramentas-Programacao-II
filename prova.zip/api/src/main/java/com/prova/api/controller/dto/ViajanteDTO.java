package com.prova.api.controller.dto;

import java.util.Date;

public record ViajanteDTO(String cpf, String nome, Date datanasc) {
}
