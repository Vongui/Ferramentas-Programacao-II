package com.prova.api.model;

import java.io.Serializable;

public class ItensId implements Serializable {

    private int idPacote;

    private int idAdicionais;
}
