package com.prova.api.controller.dto;

public record ClienteDTO (int id, String nome, String cpf){

}
